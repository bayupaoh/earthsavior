<?php
		define("DB_HOST", "localhost");
		define("DB_USER", "u618897351_user");
		define("DB_PASSWORD", "fujitsu");
		define("DB_DATABASE", "u618897351_earth");
?>